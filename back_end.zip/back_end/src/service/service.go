package service

//type Service interface {
//	GetHandler(handlerName auth.APIPermissionCode) gin.HandlerFunc
//}
