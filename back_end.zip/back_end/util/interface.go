package util


type ShutdownCallback func(f func())