{
 "routePath": "/login_action",
 "routeCode": "var found = database({type: \"account\", \"username\": params.username}).first()\nif (!found) {\n    return render_template(\"redirect.handlebars\", {redirectTo:\"login\"})\n}\n\nif (found.password == \"\" + hash(params.password + \"\" + found.salt)) {\n    session.loggedIn = true\n    if (found.username == \"admin\") {\n        session.isAdmin = true;\n    }\n    return render_template(\"redirect.handlebars\", {redirectTo:\"index\"})\n} else {\n    return render_template(\"redirect.handlebars\", {redirectTo:\"login\"})\n}"
}