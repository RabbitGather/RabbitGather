{
 "routePath": "/logout",
 "routeCode": "session.loggedIn = false;\ndelete session.isAdmin;\nreturn render_template(\"redirect.handlebars\", {redirectTo:\"index\"});"
}