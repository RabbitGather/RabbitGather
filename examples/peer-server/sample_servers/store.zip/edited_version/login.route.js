{
 "routePath": "/login",
 "routeCode": "container = static_file(\"container.html\");\ncontent = static_file(\"login.html\");\n$container = $(container);\n$content = $container.find(\"#content\");\n$content.append(content);\n\n$dummy = $(\"<div></div>\");\n$dummy.append($container);\nreturn $dummy.html();"
}